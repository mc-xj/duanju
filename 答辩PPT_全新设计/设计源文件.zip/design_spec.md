<!-- ppt-master-schema: design-spec/v1 -->
# 破晓龙城全新答辩 - Design Spec

## I. Project Information

| Item | Value |
| --- | --- |
| Project Name | 破晓龙城·全新课程答辩 |
| Canvas Format | ppt169 · 1280×720 |
| Page Count | 14 |
| Primary Language | zh-CN |
| Target Audience | 《AI媒体内容创作与实践》课程答辩教师与同学，关注主题表达、制作方法及团队个人贡献。 |
| Communication Intent | 在5—7分钟的现场答辩中，解释《破晓龙城》的主题与情感，展示剧本、分镜、关键帧、图生视频和剪辑的具体制作过程，并明确三位成员的暂定分工及交付物。 |
| Desired Audience Outcome | 评委能理解为什么创作这部短剧、红布如何承载人物情感、团队怎样控制AI素材的一致性与叙事，以及每位成员负责的工作。 |
| Core Message / Ask / Action | AI提供素材生成能力，团队通过镜头设计、人工校验与后期合成，让普通人的牺牲被看见，让和平与青年责任成为可以感受的主题。 |
| Delivery Context | 以中文主讲的现场课程答辩为主，讲述目标约6分钟；页面用于投影，不堆叠大段报告文字。切换与内容出场动画用于讲解步骤、因果与情绪递进。 |
| Artifact Afterlife | 交付可编辑PPTX和逐页演讲备注，便于修改姓名、分工与内容；保留设计源文件，完成检查后推送到GitHub主分支。 |
| Reading Mode | presentation |
| Content Strategy | 从头生成，不借鉴已有PPT；不是单纯的图片堆砌；体现每个人的分工、具体制作过程、主题和要表达的情感。 |
| Design Style | 红线叙事：电影叙事与编辑式制作证据 |
| AI Image Acquisition Path | not applicable · provided images only |
| Generation Mode | continuous |
| Spec Refinement | disabled · user delegated remaining decisions |
| Speaker Notes | enabled — user confirmed editable deck with slide notes |
| Custom Animations | enabled — explicit user request for transitions and animations |
| Narration Audio | disabled — workflow default; live presentation |
| Created Date | 2026-11-14 |

## II. Canvas Specification

| Property | Value |
| --- | --- |
| Format | PPT 16:9 |
| Dimensions | 1280 × 720 |
| viewBox | `0 0 1280 720` |
| Margins | 56px horizontal; meaningful content within y24—704 |
| Content Area | x56—1224; body below page-specific title |

## III. Visual Theme

### Theme Style

- **Mode**: custom
- **Mode References**: narrative, instructional
- **Mode Behavior**: 以人物与红布的故事提出主题，进入以真实镜号组织的制作解释，最后让延伸片尾将记忆落回今天；narrative负责总叙事，instructional只负责制作步骤的理解顺序。
- **Visual style**: custom
- **Visual Style References**: editorial
- **Visual Style Behavior**: 采用editorial的衬线标题与无衬线正文、细规则和不等宽留白；暖纸色用于制作解释，深炭青用于封面与收束，朱红信物线在不同页面转换为过程路径、注释或叙事连接。图片服务明确的证据和情感任务，原生图形承载交接与制作方法。
- **Theme**: 一根朱红的信物线，连接旧书、战场、校验与今天；随页面任务变化位置和尺度。
- **Tone**: 克制、温暖、可信，有情感而不渲染口号。

### Color Scheme

| Role | HEX | Purpose |
| --- | --- | --- |
| background | #F1E9DD | 跨页稳定语义角色 |
| secondary_bg | #E5DDD0 | 跨页稳定语义角色 |
| primary | #101B21 | 跨页稳定语义角色 |
| accent | #B44739 | 跨页稳定语义角色 |
| secondary_accent | #C8A46B | 跨页稳定语义角色 |
| body_text | #1C292D | 跨页稳定语义角色 |
| secondary_text | #586461 | 跨页稳定语义角色 |
| divider | #C6BFB4 | 跨页稳定语义角色 |
| on_dark | #F1E9DD | 跨页稳定语义角色 |
| secondary_on_dark | #B7BDB8 | 跨页稳定语义角色 |

## IV. Typography System

### Font Plan

| Role | Character (Reference) | Primary | English if non-English | Fallback tail |
| --- | --- | --- | --- | --- |
| Title | 编辑式衬线 | FangSong | Georgia | serif |
| Body | 投影用无衬线 | Microsoft YaHei | Arial | sans-serif |
| Display | 片名与结语 | FangSong | Georgia | serif |
| Metric | 规模与时长数字 | Microsoft YaHei | Arial | sans-serif |

- **Title stack**: FangSong, Georgia
- **Body stack**: Microsoft YaHei, Arial
- **Display stack**: FangSong, Georgia
- **Metric stack**: Microsoft YaHei, Arial
- **Role rationale**: display承担片名和结语，metric保持数字齐线；其余支持角色继承正文，形成清晰而有限的层级。

### Font Size Hierarchy

| Purpose | Anchor Size (px) |
| --- | ---: |
| Body | 28 |
| Title | 48 |
| Subtitle | 32 |
| Lead | 32 |
| Annotation | 20 |
| Caption | 22 |
| Footnote | 16 |
| Display | 88 |
| Metric | 88 |
| Hero | 128 |

## V. Layout Principles

### Deck-wide Direction

- **Hierarchy direction**: 先看本页判断，再看证据或关系，最后看短结论。
- **Composition tendency**: 情感页由大画面与留白主导，制作页由步骤、对照与注释主导；不以固定图片框套用所有页面。
- **Cross-page continuity**: 红线和旧书的记忆线索保持可识别；P09至P10保留同一镜头画面，变化来自动作节拍和约束解释。
- **Spacing posture**: variable by page rhythm
- **Spacing anchors**: page margin=56; block gap=24; column gutter=32; corner radius=0; body leading=42

## VI. Icon Usage Specification

- **Primary bundled library**: none

| Icon Path | Suitable Scenarios |
| --- | --- |

## VIII. Image Resource List

| Filename | Dimensions | Ratio | Purpose | Type | Image pattern | Crop Policy | Acquire Via | Status | Reference | text_policy | page_role |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| image_003.png | 1448×1086 | 1.3333 | 陈峰现代造型，完整参考 | Reference | 现代与战时造型对照，保留完整参考信息 | no-crop | user | Existing | 最新课程报告中的原始素材；仅native裁切、框线或渐变衬底，不改变人物与文字 | none | local |
| image_004.png | 1448×1086 | 1.3333 | 陈峰战时造型，完整参考 | Reference | 与现代造型等尺度展示，标签另用原生文字 | no-crop | user | Existing | 最新课程报告中的原始素材；仅native裁切、框线或渐变衬底，不改变人物与文字 | none | local |
| image_012.png | 1916×821 | 2.3337 | 1-1-01雨夜宿舍，主题入口与分镜案例 | Keyframe | 封面电影画面与制作页的同镜号证据相互呼应 | adaptive | user | Existing | 最新课程报告中的原始素材；仅native裁切、框线或渐变衬底，不改变人物与文字 | none | local |
| image_014.png | 1916×821 | 2.3337 | 1-11-07城楼对话与右腕红布 | Keyframe | 保留双人和红布，连续两页复用画面以解释静帧到运动 | adaptive | user | Existing | 最新课程报告中的原始素材；仅native裁切、框线或渐变衬底，不改变人物与文字 | none | local |
| image_016.png | 1916×821 | 2.3337 | E01抗战坚守主题 | Ending card | 延伸片尾的战场记忆起点，完整原文案 | no-crop | user | Existing | 最新课程报告中的原始素材；仅native裁切、框线或渐变衬底，不改变人物与文字 | none | local |
| image_018.png | 1916×821 | 2.3337 | E03军装勋章老兵与守护 | Ending card | 与战场和桌面静物构成三段情绪对照，保留文案 | no-crop | user | Existing | 最新课程报告中的原始素材；仅native裁切、框线或渐变衬底，不改变人物与文字 | none | local |
| image_021.png | 1916×821 | 2.3337 | E06旧书红布与铭记 | Ending card | 延伸片尾及结语保留完整画面，原生标题独立于图内文案 | no-crop | user | Existing | 最新课程报告中的原始素材；仅native裁切、框线或渐变衬底，不改变人物与文字 | none | local |

## IX. Content Outline

### Part 1: 情感、方法与团队贡献

#### Slide 01 - 破晓龙城

- **Audience move**: 陌生项目→理解作品情感入口
- **Relationships**: 旧书、红布与陈峰的记忆相连
- **Composition**: 以当前判断与证据的语义关系组织画面，采用编辑式层级与红线线索。
- **Title**: 破晓龙城
- **Core message**: 以红布与普通人的记忆建立答辩主题
- **Content**:
  - 让一个普通人的名字，留在天亮以后
  - AI短剧课程设计
  - 三位成员姓名
- **Images**: image_012.png；角色图完整对照，关键帧保护人物与红布，片尾图保留文案。
- **Cover impact**: 让一个普通人的名字，留在天亮以后；以雨夜画面、朱红线与原生片名建立入口。

#### Slide 02 - 胜利之后，仍有人值得被记住

- **Audience move**: 战争题材印象→具体人物价值
- **Relationships**: 战争代价与今日和平形成对照
- **Composition**: 以当前判断与证据的语义关系组织画面，采用编辑式层级与红线线索。
- **Title**: 胜利之后，仍有人值得被记住
- **Core message**: 铭记普通牺牲者是主题核心
- **Content**:
  - 主题：铭记先辈、珍爱和平
  - 信物：王根生的红布
  - 情绪：从热血走向克制的致敬
- **Images**: image_014.png；角色图完整对照，关键帧保护人物与红布，片尾图保留文案。

#### Slide 03 - 一次穿越，改变他理解历史的方式

- **Audience move**: 知道题材→看懂故事因果
- **Relationships**: 陈峰阅读史料→成为陈小满并经历牺牲→归来后铭记普通人
- **Composition**: 以当前判断与证据的语义关系组织画面，采用编辑式层级与红线线索。
- **Title**: 一次穿越，改变他理解历史的方式
- **Core message**: 故事以现代—战时—归来的身份变化串联
- **Content**:
  - 现代：想改写历史
  - 战时：情报要核验，行动有代价
  - 归来：把名字和牺牲记住
- **Images**: image_012.png, image_014.png；角色图完整对照，关键帧保护人物与红布，片尾图保留文案。
- **Motion suggestion**: 依据叙事或制作步骤的先后逐步揭示，先保留上下文，再突出当前信息。

#### Slide 04 - 104镜剧情，延伸为10分36秒的完整表达

- **Audience move**: 泛泛作品介绍→理解制作边界
- **Relationships**: 592秒剧情＋8秒原片尾说明＋36秒延伸片尾＝636秒；12场包含104个剧情镜头
- **Composition**: 以当前判断与证据的语义关系组织画面，采用编辑式层级与红线线索。
- **Title**: 104镜剧情，延伸为10分36秒的完整表达
- **Core message**: 用镜号和总时长约束制作规模
- **Content**:
  - 完整设计总长10:36
  - 12场104镜
  - 另6镜延伸片尾，各6秒
  - 设计规格24fps、1916×821
  - 不冒充成片实测编码

#### Slide 05 - 三人分工，围绕同一镜号交接

- **Audience move**: 只见团队名→理解个人贡献和交接
- **Relationships**: 武琮浩负责选题剧本统筹→王珽沣负责分镜角色关键帧→杨义负责图生视频剪辑声音
- **Composition**: 以当前判断与证据的语义关系组织画面，采用编辑式层级与红线线索。
- **Title**: 三人分工，围绕同一镜号交接
- **Core message**: 清晰职责与交付物支撑协作
- **Content**:
  - 暂定分工，可编辑
  - 武琮浩交付剧情与台词
  - 王珽沣交付执行卡与关键帧
  - 杨义交付镜头片段与视听合成
  - 镜号贯穿交接
- **Motion suggestion**: 依据叙事或制作步骤的先后逐步揭示，先保留上下文，再突出当前信息。

#### Slide 06 - 从剧本到成片，每一步都有交付物

- **Audience move**: 工具名称堆列→理解具体制作顺序
- **Relationships**: 选题剧本→分镜提示词→人物参考→关键帧→图生视频→后期合成；校验失败回到对应阶段
- **Composition**: 以当前判断与证据的语义关系组织画面，采用编辑式层级与红线线索。
- **Title**: 从剧本到成片，每一步都有交付物
- **Core message**: 制作流程依靠人工校验闭环
- **Content**:
  - ChatGPT、豆包辅助编剧与校对
  - 图像生成制作参考与关键帧
  - Seedance 2.0完成受控运动
  - 剪映管理画面声音文字
  - Git保存版本
- **Motion suggestion**: 依据叙事或制作步骤的先后逐步揭示，先保留上下文，再突出当前信息。

#### Slide 07 - 一个镜头，只保留一个核心动作

- **Audience move**: 看见成图→理解分镜与提示词如何约束生成
- **Relationships**: 1-1-01：时代场景、视觉锚点、动作节拍与声音相互约束
- **Composition**: 以当前判断与证据的语义关系组织画面，采用编辑式层级与红线线索。
- **Title**: 一个镜头，只保留一个核心动作
- **Core message**: 提示词先限定动作和空间再追求风格
- **Content**:
  - 镜号1-1-01、有效6秒
  - 0—2秒建立宿舍、2—4秒露出旧书地图、4—6秒停留雨窗
  - 时代前缀＋角色锚点＋本镜动作＋运镜＋负向词
  - 准确书名年份后期叠加
- **Images**: image_012.png；角色图完整对照，关键帧保护人物与红布，片尾图保留文案。
- **Motion suggestion**: 依据叙事或制作步骤的先后逐步揭示，先保留上下文，再突出当前信息。

#### Slide 08 - 先锁身份，再允许角色运动

- **Audience move**: 角色图展示→理解一致性约束
- **Relationships**: 现代陈峰与战时陈小满共享身份特征，服装道具按时代改变
- **Composition**: 以当前判断与证据的语义关系组织画面，采用编辑式层级与红线线索。
- **Title**: 先锁身份，再允许角色运动
- **Core message**: 两套造型保持身份联系并区分时代
- **Content**:
  - 现代：黑框眼镜、灰卫衣
  - 战时：灰布军装、绑腿
  - 魏大勇就是和尚
  - 脸、服装、道具三项分别检查
- **Images**: image_003.png, image_004.png；角色图完整对照，关键帧保护人物与红布，片尾图保留文案。

#### Slide 09 - 先把画面做对，再让它动起来

- **Audience move**: 只看电影感→学会按叙事检查画面
- **Relationships**: 1-11-07的同一人物、右腕红布与傍晚光线共同构成连续性
- **Composition**: 以当前判断与证据的语义关系组织画面，采用编辑式层级与红线线索。
- **Title**: 先把画面做对，再让它动起来
- **Core message**: 关键帧校验比增加形容词更重要
- **Content**:
  - 案例1-11-07
  - 检查同一张脸、右腕红布、傍晚金灰逆光
  - 不以静帧正确推定整段视频正确
- **Images**: image_014.png；角色图完整对照，关键帧保护人物与红布，片尾图保留文案。

#### Slide 10 - 把复杂表演，拆成可控的微动作

- **Audience move**: 静态校验→理解视频生成的约束设计
- **Relationships**: 延续P09的1-11-07画面：0—2秒关注红布、2—4秒对白承接、4—6秒沉默反应
- **Composition**: 以当前判断与证据的语义关系组织画面，采用编辑式层级与红线线索。
- **Title**: 把复杂表演，拆成可控的微动作
- **Core message**: 运动生成需要节拍和不变项
- **Content**:
  - Seedance 2.0以审核关键帧为视觉条件
  - 锁定站位与军装，只保留视线和呼吸
  - 失败时先降低动作复杂度
  - 对白独立配音
  - 动作设计示意而非平台操作记录
- **Images**: image_014.png；角色图完整对照，关键帧保护人物与红布，片尾图保留文案。
- **Motion suggestion**: 依据叙事或制作步骤的先后逐步揭示，先保留上下文，再突出当前信息。
- **Motion suggestion**: 延续P09的关键帧与校验锚点作为Morph候选，增加6秒动作节拍；若转换不稳定，保持画面不动并渐入说明。

#### Slide 11 - 剪辑让画面、声音与文字各司其职

- **Audience move**: 视频片段集合→理解成片视听组织
- **Relationships**: 画面、对白、环境音音乐、字幕和场景文字分轨后合成
- **Composition**: 以当前判断与证据的语义关系组织画面，采用编辑式层级与红线线索。
- **Title**: 剪辑让画面、声音与文字各司其职
- **Core message**: 后期分轨建立情绪并保护准确文字
- **Content**:
  - 剪映流程：镜号排序、粗剪、声音分轨、文字叠加、调色与导出复查
  - 雨声进入、耳鸣转场、城楼风声、片尾音乐段内收束
  - 示意不冒充真实剪辑界面
- **Motion suggestion**: 依据叙事或制作步骤的先后逐步揭示，先保留上下文，再突出当前信息。

#### Slide 12 - 让致敬，从战场走向今天

- **Audience move**: 正片结束→理解片尾的情绪与主题作用
- **Relationships**: 坚守→欢庆→致敬→传承→安宁→铭记；六镜构成有序延伸
- **Composition**: 以当前判断与证据的语义关系组织画面，采用编辑式层级与红线线索。
- **Title**: 让致敬，从战场走向今天
- **Core message**: 延伸片尾把历史记忆转化为现实责任
- **Content**:
  - 6镜×6秒＝36秒
  - 山河不屈、胜利的曙光、致敬守护者、不负青春、珍爱和平、铭记先辈
  - 低强度动画保护中文、勋章、报纸与红布
  - 老兵不是王根生生还
- **Images**: image_016.png, image_018.png, image_021.png；角色图完整对照，关键帧保护人物与红布，片尾图保留文案。
- **Motion suggestion**: 依据叙事或制作步骤的先后逐步揭示，先保留上下文，再突出当前信息。

#### Slide 13 - 可追溯，比一次生成成功更重要

- **Audience move**: 关注生成技巧→理解可复用的方法与不足
- **Relationships**: 镜号关联脚本、提示词、关键帧和生成表；真实性与艺术表达须共同复核
- **Composition**: 以当前判断与证据的语义关系组织画面，采用编辑式层级与红线线索。
- **Title**: 可追溯，比一次生成成功更重要
- **Core message**: 约束、校验和后期把素材变成故事
- **Content**:
  - 已核验：104张分镜PNG、8张角色参考
  - 经验：一致性靠锚点、可信度靠记录、情绪靠剪辑
  - 真实参数及平台截图仍需留痕，不编造成功率

#### Slide 14 - 记住普通人的名字，珍惜今天的和平

- **Audience move**: 了解制作过程→带走作品的核心情感
- **Relationships**: 红布、旧书与当下的阅读和努力相连
- **Composition**: 以当前判断与证据的语义关系组织画面，采用编辑式层级与红线线索。
- **Title**: 记住普通人的名字，珍惜今天的和平
- **Core message**: 主题落点是对当下的理解与责任
- **Content**:
  - AI生成素材，人的判断连接故事
  - 观看完整成片
  - 武琮浩、王珽沣、杨义
  - 暂定分工可编辑
- **Images**: image_021.png；角色图完整对照，关键帧保护人物与红布，片尾图保留文案。
- **Closing impact**: 记住普通人的名字，珍惜今天的和平；旧书与红布回应开场。
- **Hyperlinks**: 观看完整成片 https://mega.nz/folder/0ygUwKqB#haymSgIw2WrSx8Ba8f3yeQ

## X. Speaker Notes Requirements

- **Generation**: enabled
- **Filename**: match each SVG filename under notes/
- **Content**: 以最新课程报告、剧本和用户批准的暂定分工为依据；不照读页面，不编造实际平台运行日志与成功率；各页加自然衔接。
- **Total duration**: 360秒建议讲述时间，现场排练控制5—7分钟
- **Notes style**: 中文自然答辩语气，有解释、有情绪落点，避免过密形容词
- **Presentation purpose**: 说明主题、具体制作过程与三位同学的暂定贡献
