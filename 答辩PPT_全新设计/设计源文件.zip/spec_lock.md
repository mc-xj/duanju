<!-- ppt-master-schema: spec-lock/v1 -->
# Execution Lock

## canvas
- viewBox: 0 0 1280 720
- format: ppt169

## communication
- primary_language: zh-CN
- audience: AI媒体课程答辩教师与同学
- objective: 在5—7分钟内使评委理解主题情感、具体制作过程和三人暂定分工，作品数据可追溯。
- core_message: AI生成素材，团队的镜头设计、校验与剪辑让普通人的牺牲被看见、让和平与青年责任被感受。
- consumption_mode: presentation

## mode
- mode: custom
- mode_references: narrative, instructional
- mode_behavior: 以人物与红布的故事提出主题，进入以真实镜号组织的制作解释，最后让延伸片尾将记忆落回今天；narrative负责总叙事，instructional只负责制作步骤的理解顺序。

## visual_style
- visual_style: custom
- visual_style_references: editorial
- visual_style_behavior: 采用editorial的衬线标题与无衬线正文、细规则和不等宽留白；暖纸色用于制作解释，深炭青用于封面与收束，朱红信物线在不同页面转换为过程路径、注释或叙事连接。图片服务明确的证据和情感任务，原生图形承载交接与制作方法。

## colors
- background: #F1E9DD
- secondary_bg: #E5DDD0
- primary: #101B21
- accent: #B44739
- secondary_accent: #C8A46B
- body_text: #1C292D
- secondary_text: #586461
- divider: #C6BFB4
- on_dark: #F1E9DD
- secondary_on_dark: #B7BDB8

## typography
- font_family: Microsoft YaHei, Arial
- title_family: FangSong, Georgia
- body_family: Microsoft YaHei, Arial
- display_family: FangSong, Georgia
- metric_family: Microsoft YaHei, Arial
- body: 28
- title: 48
- subtitle: 32
- lead: 32
- annotation: 20
- caption: 22
- footnote: 16
- display: 88
- metric: 88
- hero: 128

## icons
- library: none
- inventory: none

## images
- asset01: images/image_003.png | source=user | crop=no-crop
- asset02: images/image_004.png | source=user | crop=no-crop
- asset03: images/image_012.png | source=user | crop=adaptive
- asset05: images/image_014.png | source=user | crop=adaptive
- asset06: images/image_016.png | source=user | crop=no-crop
- asset07: images/image_018.png | source=user | crop=no-crop
- asset08: images/image_021.png | source=user | crop=no-crop

## page_rhythm
- P01: anchor
- P02: breathing
- P03: dense
- P04: breathing
- P05: dense
- P06: dense
- P07: dense
- P08: dense
- P09: dense
- P10: dense
- P11: dense
- P12: dense
- P13: dense
- P14: anchor

## pptx_structure
- mode: flat

## forbidden
- `mask`, `<style>`, `class`, external CSS, `<foreignObject>`, `textPath`, `@font-face`, `<animate*>`, `<set>`, `<script>` / event attributes, `<iframe>`
- HTML named entities in text; write typography as raw Unicode and escape XML reserved characters
- 不要借鉴已有的ppt (user)
