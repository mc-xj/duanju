<!-- ppt-master-schema: design-spec/v1 -->
# 破晓龙城融合答辩 - Design Spec

## I. Project Information

| Item | Value |
| --- | --- |
| Project Name | 破晓龙城·融合完整版 |
| Canvas Format | ppt169 · 1280×720 |
| Page Count | 16 |
| Primary Language | zh-CN |
| Target Audience | 《AI媒体内容创作与实践》课程答辩教师与同学，关注主题表达、制作方法及团队个人贡献。 |
| Communication Intent | 在5—7分钟的现场答辩中，解释《破晓龙城》的主题与情感，展示剧本、分镜、关键帧、图生视频和剪辑的具体制作过程，并明确三位成员的暂定分工及交付物。 |
| Desired Audience Outcome | 评委能理解为什么创作这部短剧、红布如何承载人物情感、团队怎样控制AI素材的一致性与叙事，以及每位成员负责的工作。 |
| Core Message / Ask / Action | AI提供素材生成能力，团队通过镜头设计、人工校验与后期合成，让普通人的牺牲被看见，让和平与青年责任成为可以感受的主题。 |
| Delivery Context | 以中文主讲的现场课程答辩为主，讲述目标约6分钟；页面用于投影，不堆叠大段报告文字。切换与内容出场动画用于讲解步骤、因果与情绪递进。 |
| Artifact Afterlife | 交付可编辑PPTX和逐页演讲备注，便于修改姓名、分工与内容；保留设计源文件，完成检查后推送到GitHub主分支。 |
| Reading Mode | presentation |
| Content Strategy | 融合两版已有设计源文件并重新编排：总介绍→主题情感→暂定分工→制作流程→具体案例→后期→片尾→主题重申与情感升华。衔接依靠信物红布、跨时代造型与两次白闪。 |
| Design Style | 红布叙事与制作手记融合 |
| AI Image Acquisition Path | not applicable · provided images only |
| Generation Mode | continuous |
| Spec Refinement | disabled · user delegated remaining decisions |
| Speaker Notes | enabled — user confirmed editable deck with slide notes |
| Custom Animations | enabled — explicit user request for transitions and animations |
| Narration Audio | disabled — workflow default; live presentation |
| Created Date | 2026-11-14 |

## II. Canvas Specification

| Property | Value |
| --- | --- |
| Format | PPT 16:9 |
| Dimensions | 1280 × 720 |
| viewBox | `0 0 1280 720` |
| Margins | 56px horizontal; meaningful content within y24—704 |
| Content Area | x56—1224; body below page-specific title |

## III. Visual Theme

### Theme Style

- **Mode**: custom
- **Mode References**: narrative, instructional
- **Mode Behavior**: 以人物与红布的故事提出主题，进入以真实镜号组织的制作解释，最后让延伸片尾将记忆落回今天；narrative负责总叙事，instructional只负责制作步骤的理解顺序。
- **Visual style**: custom
- **Visual Style References**: editorial
- **Visual Style Behavior**: 采用editorial的衬线标题与无衬线正文、细规则和不等宽留白；暖纸色用于制作解释，深炭青用于封面与收束，朱红信物线在不同页面转换为过程路径、注释或叙事连接。图片服务明确的证据和情感任务，原生图形承载交接与制作方法。
- **Theme**: 一根朱红的信物线，连接旧书、战场、校验与今天；随页面任务变化位置和尺度。
- **Tone**: 克制、温暖、可信，有情感而不渲染口号。

### Color Scheme

| Role | HEX | Purpose |
| --- | --- | --- |
| background | #F1E9DD | 跨页稳定语义角色 |
| secondary_bg | #E5DDD0 | 跨页稳定语义角色 |
| primary | #101B21 | 跨页稳定语义角色 |
| accent | #B44739 | 跨页稳定语义角色 |
| secondary_accent | #C8A46B | 跨页稳定语义角色 |
| body_text | #1C292D | 跨页稳定语义角色 |
| secondary_text | #586461 | 跨页稳定语义角色 |
| divider | #C6BFB4 | 跨页稳定语义角色 |
| on_dark | #F1E9DD | 跨页稳定语义角色 |
| secondary_on_dark | #B7BDB8 | 跨页稳定语义角色 |

## IV. Typography System

### Font Plan

| Role | Character (Reference) | Primary | English if non-English | Fallback tail |
| --- | --- | --- | --- | --- |
| Title | 编辑式衬线 | FangSong | Georgia | serif |
| Body | 投影用无衬线 | Microsoft YaHei | Arial | sans-serif |
| Display | 片名与结语 | FangSong | Georgia | serif |
| Metric | 规模与时长数字 | Microsoft YaHei | Arial | sans-serif |

- **Title stack**: FangSong, Georgia
- **Body stack**: Microsoft YaHei, Arial
- **Display stack**: FangSong, Georgia
- **Metric stack**: Microsoft YaHei, Arial
- **Role rationale**: display承担片名和结语，metric保持数字齐线；其余支持角色继承正文，形成清晰而有限的层级。

### Font Size Hierarchy

| Purpose | Anchor Size (px) |
| --- | ---: |
| Body | 28 |
| Title | 48 |
| Subtitle | 32 |
| Lead | 32 |
| Annotation | 20 |
| Caption | 22 |
| Footnote | 16 |
| Display | 88 |
| Metric | 88 |
| Hero | 128 |

## V. Layout Principles

### Deck-wide Direction

- **Hierarchy direction**: 先看本页判断，再看证据或关系，最后看短结论。
- **Composition tendency**: 情感页由大画面与留白主导，制作页由步骤、对照与注释主导；不以固定图片框套用所有页面。
- **Cross-page continuity**: 红线和旧书的记忆线索保持可识别；P06—P08用宿舍案例承接流程；P09用跨时代角色衔接P10—P12城楼案例；P13—P16从后期到片尾、现实责任与铭记，变化来自动作节拍和约束解释。
- **Spacing posture**: variable by page rhythm
- **Spacing anchors**: page margin=56; block gap=24; column gutter=32; corner radius=0; body leading=42

## VI. Icon Usage Specification

- **Primary bundled library**: none

| Icon Path | Suitable Scenarios |
| --- | --- |

## VIII. Image Resource List

| Filename | Dimensions | Ratio | Purpose | Type | Image pattern | Crop Policy | Acquire Via | Status | Reference | text_policy | page_role |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| image_003.png | 1448×1086 | 1.3333 | 报告原图003：角色、TXT、镜头或片尾证据 | Evidence | 原图保留主体，原生解释与批注 | no-crop | user | Existing | 课程报告及原始仓库素材 | none | local |
| image_004.png | 1448×1086 | 1.3333 | 报告原图004：角色、TXT、镜头或片尾证据 | Evidence | 原图保留主体，原生解释与批注 | no-crop | user | Existing | 课程报告及原始仓库素材 | none | local |
| image_009.png | 1200×991 | 1.2109 | 报告原图009：角色、TXT、镜头或片尾证据 | Evidence | 原图保留主体，原生解释与批注 | no-crop | user | Existing | 课程报告及原始仓库素材 | none | local |
| image_011.png | 1200×1031 | 1.1639 | 报告原图011：角色、TXT、镜头或片尾证据 | Evidence | 原图保留主体，原生解释与批注 | no-crop | user | Existing | 课程报告及原始仓库素材 | none | local |
| image_012.png | 1916×821 | 2.3337 | 报告原图012：角色、TXT、镜头或片尾证据 | Evidence | 原图保留主体，原生解释与批注 | adaptive | user | Existing | 课程报告及原始仓库素材 | none | local |
| image_013.png | 1916×821 | 2.3337 | 报告原图013：角色、TXT、镜头或片尾证据 | Evidence | 原图保留主体，原生解释与批注 | adaptive | user | Existing | 课程报告及原始仓库素材 | none | local |
| image_014.png | 1916×821 | 2.3337 | 报告原图014：角色、TXT、镜头或片尾证据 | Evidence | 原图保留主体，原生解释与批注 | adaptive | user | Existing | 课程报告及原始仓库素材 | none | local |
| image_015.png | 1916×821 | 2.3337 | 报告原图015：角色、TXT、镜头或片尾证据 | Evidence | 原图保留主体，原生解释与批注 | adaptive | user | Existing | 课程报告及原始仓库素材 | none | local |
| image_016.png | 1916×821 | 2.3337 | 报告原图016：角色、TXT、镜头或片尾证据 | Evidence | 原图保留主体，原生解释与批注 | no-crop | user | Existing | 课程报告及原始仓库素材 | none | local |
| image_018.png | 1916×821 | 2.3337 | 报告原图018：角色、TXT、镜头或片尾证据 | Evidence | 原图保留主体，原生解释与批注 | no-crop | user | Existing | 课程报告及原始仓库素材 | none | local |
| image_019.png | 1916×821 | 2.3337 | 报告原图019：角色、TXT、镜头或片尾证据 | Evidence | 原图保留主体，原生解释与批注 | no-crop | user | Existing | 课程报告及原始仓库素材 | none | local |
| image_020.png | 1916×821 | 2.3337 | 报告原图020：角色、TXT、镜头或片尾证据 | Evidence | 原图保留主体，原生解释与批注 | no-crop | user | Existing | 课程报告及原始仓库素材 | none | local |
| image_021.png | 1916×821 | 2.3337 | 报告原图021：角色、TXT、镜头或片尾证据 | Evidence | 原图保留主体，原生解释与批注 | no-crop | user | Existing | 课程报告及原始仓库素材 | none | local |

## IX. Content Outline

#### Slide 01 - 破晓龙城

- **Audience move**: 以一个普通人的名字引入主题
- **Relationships**: none
- **Composition**: 雨夜宿舍与原生片名、信物红线
- **Title**: 破晓龙城
- **Core message**: 让一个普通人的名字留在天亮以后；武琮浩、王珽沣、杨义；总介绍—案例—主题回归
- **Content**:
  - 让一个普通人的名字留在天亮以后；武琮浩、王珽沣、杨义；总介绍—案例—主题回归
- **Images**: image_012.png
- **Native-ready**: none
- **Cover impact**: 人物名字留在天亮以后，雨夜画面引入普通人的记忆。

#### Slide 02 - 一部穿越短剧，讲述一次理解的改变

- **Audience move**: 理解作品设定与规模
- **Relationships**: order: 现代研究→战时经历→归来铭记；membership: 12场104镜剧情与6镜延伸片尾
- **Composition**: 三段叙事路径配静帧，下方完整设计规格
- **Title**: 一部穿越短剧，讲述一次理解的改变
- **Core message**: 陈峰进入架空1945年成为陈小满；情报需核验、行动有代价；归来铭记普通人。12场104镜，含片尾设计总长10:36；设计24fps、分镜1916×821
- **Content**:
  - 陈峰进入架空1945年成为陈小满；情报需核验、行动有代价；归来铭记普通人。12场104镜，含片尾设计总长10:36；设计24fps、分镜1916×821
- **Images**: image_012.png,image_014.png
- **Native-ready**: none

#### Slide 03 - 胜利之后，仍有人值得被记住

- **Audience move**: 从故事设定进入人物情感
- **Relationships**: link: 红布连起王根生的牺牲、陈峰的记忆与今日责任
- **Composition**: 原版情感主张、红布画面与克制留白
- **Title**: 胜利之后，仍有人值得被记住
- **Core message**: 普通人的牺牲被另一个人记住；铭记先辈、珍爱和平、将理解转化为今日责任；从热血走向克制致敬
- **Content**:
  - 普通人的牺牲被另一个人记住；铭记先辈、珍爱和平、将理解转化为今日责任；从热血走向克制致敬
- **Images**: image_014.png
- **Native-ready**: none

#### Slide 04 - 三人怎样交付同一个镜头

- **Audience move**: 让分工落到交付内容
- **Relationships**: order: 武琮浩台词情绪→王珽沣执行卡关键帧→杨义视频声音剪辑
- **Composition**: 沿用案例版三条责任带，同一1-11-07镜号贯穿
- **Title**: 三人怎样交付同一个镜头
- **Core message**: 拟定分工可编辑：武琮浩选题剧本统筹，王珽沣分镜角色关键帧，杨义图生视频剪辑声音；以台词、6秒卡、微动作与对白音轨交接
- **Content**:
  - 拟定分工可编辑：武琮浩选题剧本统筹，王珽沣分镜角色关键帧，杨义图生视频剪辑声音；以台词、6秒卡、微动作与对白音轨交接
- **Images**: none
- **Native-ready**: none

#### Slide 05 - 从剧本到成片，每一步都有交付物

- **Audience move**: 从人员职责到整体制作路径
- **Relationships**: order: 剧本→分镜→人物参考→关键帧→视频→后期；link: 未通过回对应阶段
- **Composition**: 沿用原版六步蛇形流程，过程后自然进入宿舍案例
- **Title**: 从剧本到成片，每一步都有交付物
- **Core message**: ChatGPT/豆包组织叙事和校对；图像生成先立参考与关键帧；Seedance 2.0受控运动；剪映视听分轨；Git保存版本。接下来用实际镜号说明
- **Content**:
  - ChatGPT/豆包组织叙事和校对；图像生成先立参考与关键帧；Seedance 2.0受控运动；剪映视听分轨；Git保存版本。接下来用实际镜号说明
- **Images**: none
- **Native-ready**: none

#### Slide 06 - 第一场：从35秒剧本，到第一张关键帧

- **Audience move**: 从总体流程落入第一个具体案例
- **Relationships**: link: TXT约束决定关键帧；order: 6+7+5+10+7秒完成五镜
- **Composition**: 左侧TXT原文截图、右侧宽幅宿舍帧与约束说明
- **Title**: 第一场：从35秒剧本，到第一张关键帧
- **Core message**: 1-1-01：当代雨夜；门左后窗右后；冷蓝窗光与暖黄台灯；桌面旧书地图布局固定；书名年份后期叠加；静帧可见布局和光线
- **Content**:
  - 1-1-01：当代雨夜；门左后窗右后；冷蓝窗光与暖黄台灯；桌面旧书地图布局固定；书名年份后期叠加；静帧可见布局和光线
- **Images**: image_009.png,image_012.png
- **Native-ready**: none

#### Slide 07 - 1-1-01：横移失稳时，先减少运动

- **Audience move**: 从首帧约束到视频控制
- **Relationships**: order: 基线横移→如漂移减幅→仍失败静帧轻推
- **Composition**: 沿用案例版宿舍首帧、六秒基线及三个回退阶段
- **Title**: 1-1-01：横移失稳时，先减少运动
- **Core message**: 0—2建立，2—4旧书地图，4—6雨窗；验台灯、书页和新增元素；仅说明复现及回退方案，真实前后视频待补
- **Content**:
  - 0—2建立，2—4旧书地图，4—6雨窗；验台灯、书页和新增元素；仅说明复现及回退方案，真实前后视频待补
- **Images**: image_012.png
- **Native-ready**: none

#### Slide 08 - 1-1-04：白光不能先把动作抹掉

- **Audience move**: 把空间控制延伸到动作可读性
- **Relationships**: order: 雷声→惊起→白光
- **Composition**: 沿用案例版暗底雷光关键帧加三项观察
- **Title**: 1-1-04：白光不能先把动作抹掉
- **Core message**: 10秒有效段；人物惊起、椅子偏倒、亮屏可辨；图像保起点、视频与后期完成白闪；避免首帧全白
- **Content**:
  - 10秒有效段；人物惊起、椅子偏倒、亮屏可辨；图像保起点、视频与后期完成白闪；避免首帧全白
- **Images**: image_013.png
- **Native-ready**: none

#### Slide 09 - 同一张脸，分清两套时代造型

- **Audience move**: 通过角色转变衔接现代与战时案例
- **Relationships**: contrast: 身份保持，时代服装改变
- **Composition**: 沿用两幅完整三视图与检查结论
- **Title**: 同一张脸，分清两套时代造型
- **Core message**: 现代眼镜灰卫衣；战时军装绑腿布鞋尘土；分开引用；名字不能单独锁身份；魏大勇=和尚
- **Content**:
  - 现代眼镜灰卫衣；战时军装绑腿布鞋尘土；分开引用；名字不能单独锁身份；魏大勇=和尚
- **Images**: image_003.png,image_004.png
- **Native-ready**: none

#### Slide 10 - 1-11-07：红布必须是叙事焦点

- **Audience move**: 从跨时代身份进入信物情绪
- **Relationships**: link: 视线、右腕红布与城下担架关联牺牲
- **Composition**: 沿用双人原图批注及静帧/视频检查区分
- **Title**: 1-11-07：红布必须是叙事焦点
- **Core message**: 静帧可见两人、右腕红布与城下伤员；手势朝城下，不能证明先看红布的完整动作；视频验视线、面孔、腕带、站位、傍晚光线
- **Content**:
  - 静帧可见两人、右腕红布与城下伤员；手势朝城下，不能证明先看红布的完整动作；视频验视线、面孔、腕带、站位、傍晚光线
- **Images**: image_014.png
- **Native-ready**: none

#### Slide 11 - 1-11-07：把一句台词拆成六秒表演

- **Audience move**: 从静帧线索到节拍与对白分工
- **Relationships**: order: 看红布→对白承接→低头沉默；link: 失败降复杂度
- **Composition**: 沿用TXT原图、精简约束和三个节拍
- **Title**: 1-11-07：把一句台词拆成六秒表演
- **Core message**: 锁两人站位、右腕红布与傍晚；固定或极小推镜、独立配音；如变形减手臂与抬头，仍失败用同轴反应镜+红布特写；非实测日志
- **Content**:
  - 锁两人站位、右腕红布与傍晚；固定或极小推镜、独立配音；如变形减手臂与抬头，仍失败用同轴反应镜+红布特写；非实测日志
- **Images**: image_011.png
- **Native-ready**: none

#### Slide 12 - 1-11-10：先看清红布，再进入白光

- **Audience move**: 将技术动作连回开头穿越
- **Relationships**: order: 0—3夕光→3—6抬右手红布→6—9渐白抽声
- **Composition**: 沿用原图与三个转场阶段
- **Title**: 1-11-10：先看清红布，再进入白光
- **Core message**: 首帧保脸、右手、腕带位置；傍晚非黎明；图像保结构、视频抬手、剪辑过曝抽声；9秒含转场
- **Content**:
  - 首帧保脸、右手、腕带位置；傍晚非黎明；图像保结构、视频抬手、剪辑过曝抽声；9秒含转场
- **Images**: image_015.png
- **Native-ready**: none

#### Slide 13 - 两次白闪，形成一次情感回环

- **Audience move**: 把案例组合成成片视听关系
- **Relationships**: contrast: 第一场进入战时与第十一场回到现实；membership: 画面声音文字分轨
- **Composition**: 沿用两条声画关系与时长公式
- **Title**: 两次白闪，形成一次情感回环
- **Core message**: 雨雷键盘→耳鸣心跳；风欢呼哭声→抽人声回现实；剪映镜号排序、对白环境音乐分轨、准确文字叠加；592+8+36=636秒，实际参数待补
- **Content**:
  - 雨雷键盘→耳鸣心跳；风欢呼哭声→抽人声回现实；剪映镜号排序、对白环境音乐分轨、准确文字叠加；592+8+36=636秒，实际参数待补
- **Images**: none
- **Native-ready**: none

#### Slide 14 - E03：老兵动得越少，致敬越清楚

- **Audience move**: 由正片后期进入延伸片尾制作
- **Relationships**: membership: 面孔接触勋章文案固定，呼吸衣角树叶微动；order: 六镜由坚守到铭记
- **Composition**: 沿用完整军装勋章老兵卡与微动/保护清单
- **Title**: E03：老兵动得越少，致敬越清楚
- **Core message**: 6秒首帧动画，不走位不转身；勋章文案静态保护；如不稳仅环境+后期轻推；老兵非王根生生还；六镜各6秒、各自首帧硬切
- **Content**:
  - 6秒首帧动画，不走位不转身；勋章文案静态保护；如不稳仅环境+后期轻推；老兵非王根生生还；六镜各6秒、各自首帧硬切
- **Images**: image_018.png
- **Native-ready**: none

#### Slide 15 - 从战场走回今天，致敬成为一种行动

- **Audience move**: 由片尾方法自然升华至当代意义
- **Relationships**: order: 战场牺牲→青年阅读记录→平凡生活安宁
- **Composition**: 三张完整片尾原图，图下每段具体意义，末行解释红布回环
- **Title**: 从战场走回今天，致敬成为一种行动
- **Core message**: E01山河不屈、E04不负青春、E05珍爱和平：看见牺牲、延续记忆、守护日常；将陈峰个人经历延展为青年责任；不把象征画面当史料
- **Content**:
  - E01山河不屈、E04不负青春、E05珍爱和平：看见牺牲、延续记忆、守护日常；将陈峰个人经历延展为青年责任；不把象征画面当史料
- **Images**: image_016.png,image_019.png,image_020.png
- **Native-ready**: none

#### Slide 16 - 记住普通人的名字，珍惜今天的和平

- **Audience move**: 以开头信物回应收束作品主题
- **Relationships**: link: 旧书红布与今日阅读、行动相连
- **Composition**: 沿用原版情感结束页与成片链接
- **Title**: 记住普通人的名字，珍惜今天的和平
- **Core message**: 旧书红布回应雨夜起点；AI生成素材，团队镜头设计和校验连接故事；观看完整成片；三人署名；致谢
- **Content**:
  - 旧书红布回应雨夜起点；AI生成素材，团队镜头设计和校验连接故事；观看完整成片；三人署名；致谢
- **Images**: image_021.png
- **Native-ready**: none
- **Closing impact**: 旧书红布与开头呼应，记住名字与珍惜和平落到今天；不以待补清单结束。
- **Hyperlinks**: 观看完整成片 https://mega.nz/folder/0ygUwKqB#haymSgIw2WrSx8Ba8f3yeQ

## X. Speaker Notes Requirements

- **Generation**: enabled
- **Filename**: match SVG filename
- **Content**: 重写整份连续讲稿，篇幅约2000—2200中文字，5—7分钟。用主题→流程→镜头→片尾→现实责任形成自然转折，不逐页重复开场，不以真实性说明替代情感结束。明确静帧证据与视频待验证内容，拟定分工保留。
- **Total duration**: 建议360秒，现场排练5—7分钟
