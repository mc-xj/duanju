<!-- ppt-master-schema: design-spec/v1 -->
# 破晓龙城案例答辩 - Design Spec

## I. Project Information

| Item | Value |
| --- | --- |
| Project Name | 破晓龙城·案例分析版 |
| Canvas Format | ppt169 · 1280×720 |
| Page Count | 14 |
| Primary Language | zh-CN |
| Target Audience | 《AI媒体内容创作与实践》课程答辩教师与同学，关注主题表达、制作方法及团队个人贡献。 |
| Communication Intent | 在5—7分钟的现场答辩中，解释《破晓龙城》的主题与情感，展示剧本、分镜、关键帧、图生视频和剪辑的具体制作过程，并明确三位成员的暂定分工及交付物。 |
| Desired Audience Outcome | 评委能理解为什么创作这部短剧、红布如何承载人物情感、团队怎样控制AI素材的一致性与叙事，以及每位成员负责的工作。 |
| Core Message / Ask / Action | AI提供素材生成能力，团队通过镜头设计、人工校验与后期合成，让普通人的牺牲被看见，让和平与青年责任成为可以感受的主题。 |
| Delivery Context | 以中文主讲的现场课程答辩为主，讲述目标约6分钟；页面用于投影，不堆叠大段报告文字。切换与内容出场动画用于讲解步骤、因果与情绪递进。 |
| Artifact Afterlife | 交付可编辑PPTX和逐页演讲备注，便于修改姓名、分工与内容；保留设计源文件，完成检查后推送到GitHub主分支。 |
| Reading Mode | presentation |
| Content Strategy | 全页重新绘制；以报告4.2—4.7的具体案例为核心，展示原文、输入、约束、可观察结果和失败回退。不将未提供的平台视频记录写成实测结果。 |
| Design Style | 制作手记：镜号、提示词与画面批注 |
| AI Image Acquisition Path | not applicable · provided images only |
| Generation Mode | continuous |
| Spec Refinement | disabled · user delegated remaining decisions |
| Speaker Notes | enabled — user confirmed editable deck with slide notes |
| Custom Animations | enabled — explicit user request for transitions and animations |
| Narration Audio | disabled — workflow default; live presentation |
| Created Date | 2026-11-14 |

## II. Canvas Specification

| Property | Value |
| --- | --- |
| Format | PPT 16:9 |
| Dimensions | 1280 × 720 |
| viewBox | `0 0 1280 720` |
| Margins | 56px horizontal; meaningful content within y24—704 |
| Content Area | x56—1224; body below page-specific title |

## III. Visual Theme

### Theme Style

- **Mode**: custom
- **Mode References**: narrative, instructional
- **Mode Behavior**: 以人物与红布的故事提出主题，进入以真实镜号组织的制作解释，最后让延伸片尾将记忆落回今天；narrative负责总叙事，instructional只负责制作步骤的理解顺序。
- **Visual style**: custom
- **Visual Style References**: editorial
- **Visual Style Behavior**: 采用editorial的衬线标题与无衬线正文、细规则和不等宽留白；暖纸色用于制作解释，深炭青用于封面与收束，朱红信物线在不同页面转换为过程路径、注释或叙事连接。图片服务明确的证据和情感任务，原生图形承载交接与制作方法。
- **Theme**: 一根朱红的信物线，连接旧书、战场、校验与今天；随页面任务变化位置和尺度。
- **Tone**: 克制、温暖、可信，有情感而不渲染口号。

### Color Scheme

| Role | HEX | Purpose |
| --- | --- | --- |
| background | #F1E9DD | 跨页稳定语义角色 |
| secondary_bg | #E5DDD0 | 跨页稳定语义角色 |
| primary | #101B21 | 跨页稳定语义角色 |
| accent | #B44739 | 跨页稳定语义角色 |
| secondary_accent | #C8A46B | 跨页稳定语义角色 |
| body_text | #1C292D | 跨页稳定语义角色 |
| secondary_text | #586461 | 跨页稳定语义角色 |
| divider | #C6BFB4 | 跨页稳定语义角色 |
| on_dark | #F1E9DD | 跨页稳定语义角色 |
| secondary_on_dark | #B7BDB8 | 跨页稳定语义角色 |

## IV. Typography System

### Font Plan

| Role | Character (Reference) | Primary | English if non-English | Fallback tail |
| --- | --- | --- | --- | --- |
| Title | 编辑式衬线 | FangSong | Georgia | serif |
| Body | 投影用无衬线 | Microsoft YaHei | Arial | sans-serif |
| Display | 片名与结语 | FangSong | Georgia | serif |
| Metric | 规模与时长数字 | Microsoft YaHei | Arial | sans-serif |

- **Title stack**: FangSong, Georgia
- **Body stack**: Microsoft YaHei, Arial
- **Display stack**: FangSong, Georgia
- **Metric stack**: Microsoft YaHei, Arial
- **Role rationale**: display承担片名和结语，metric保持数字齐线；其余支持角色继承正文，形成清晰而有限的层级。

### Font Size Hierarchy

| Purpose | Anchor Size (px) |
| --- | ---: |
| Body | 28 |
| Title | 48 |
| Subtitle | 32 |
| Lead | 32 |
| Annotation | 20 |
| Caption | 22 |
| Footnote | 16 |
| Display | 88 |
| Metric | 88 |
| Hero | 128 |

## V. Layout Principles

### Deck-wide Direction

- **Hierarchy direction**: 先看本页判断，再看证据或关系，最后看短结论。
- **Composition tendency**: 情感页由大画面与留白主导，制作页由步骤、对照与注释主导；不以固定图片框套用所有页面。
- **Cross-page continuity**: 红线和旧书的记忆线索保持可识别；P05至P06保留宿舍关键帧，变化来自动作节拍和约束解释。
- **Spacing posture**: variable by page rhythm
- **Spacing anchors**: page margin=56; block gap=24; column gutter=32; corner radius=0; body leading=42

## VI. Icon Usage Specification

- **Primary bundled library**: none

| Icon Path | Suitable Scenarios |
| --- | --- |

## VIII. Image Resource List

| Filename | Dimensions | Ratio | Purpose | Type | Image pattern | Crop Policy | Acquire Via | Status | Reference | text_policy | page_role |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| image_003.png | 1448×1086 | 1.3333 | 现代陈峰人物参考 | Evidence | 保留证据主体，原生批注解释具体问题 | no-crop | user | Existing | 课程设计报告原始嵌图 | none | local |
| image_004.png | 1448×1086 | 1.3333 | 战时陈峰人物参考 | Evidence | 保留证据主体，原生批注解释具体问题 | no-crop | user | Existing | 课程设计报告原始嵌图 | none | local |
| image_009.png | 1200×991 | 1.2109 | 报告图8，1-1-01原始TXT截图 | Evidence | 保留证据主体，原生批注解释具体问题 | no-crop | user | Existing | 课程设计报告原始嵌图 | none | local |
| image_011.png | 1200×1031 | 1.1639 | 报告图10，1-11-07原始TXT截图 | Evidence | 保留证据主体，原生批注解释具体问题 | no-crop | user | Existing | 课程设计报告原始嵌图 | none | local |
| image_012.png | 1916×821 | 2.3337 | 报告图11，宿舍建立镜头 | Evidence | 保留证据主体，原生批注解释具体问题 | adaptive | user | Existing | 课程设计报告原始嵌图 | none | local |
| image_013.png | 1916×821 | 2.3337 | 报告图12，宿舍雷光转场 | Evidence | 保留证据主体，原生批注解释具体问题 | adaptive | user | Existing | 课程设计报告原始嵌图 | none | local |
| image_014.png | 1916×821 | 2.3337 | 报告图13，城楼双人红布镜头 | Evidence | 保留证据主体，原生批注解释具体问题 | adaptive | user | Existing | 课程设计报告原始嵌图 | none | local |
| image_015.png | 1916×821 | 2.3337 | 报告图14，夕光遮挡转场 | Evidence | 保留证据主体，原生批注解释具体问题 | adaptive | user | Existing | 课程设计报告原始嵌图 | none | local |
| image_018.png | 1916×821 | 2.3337 | 报告图21，军装勋章退伍老兵 | Evidence | 保留证据主体，原生批注解释具体问题 | no-crop | user | Existing | 课程设计报告原始嵌图 | none | local |
| image_021.png | 1916×821 | 2.3337 | 报告图24，旧书红布静物 | Evidence | 保留证据主体，原生批注解释具体问题 | no-crop | user | Existing | 课程设计报告原始嵌图 | none | local |

## IX. Content Outline

#### Slide 01 - 破晓龙城：把四个镜头讲清楚

- **Audience move**: 从泛泛主题到可验证制作问题
- **Relationships**: 两组案例和片尾是答辩内容的组成
- **Composition**: 双场景开场，上半宿舍、下半城楼；原生片名与镜号目录
- **Title**: 破晓龙城：把四个镜头讲清楚
- **Core message**: 1-1-01布局；1-1-04白闪；1-11-07红布；1-11-10遮光；E03片尾
- **Content**:
  - 1-1-01布局；1-1-04白闪；1-11-07红布；1-11-10遮光；E03片尾
- **Images**: image_012.png,image_014.png
- **Topology**: no
- **Native-ready**: none
- **Cover impact**: 电影画面与镜号形成开场，立即说明本次答辩用具体案例讲制作。

#### Slide 02 - 一截红布，改变陈峰理解历史的方式

- **Audience move**: 从穿越题材到具体情感线索
- **Relationships**: 现代阅读→战时经历牺牲→现实铭记
- **Composition**: 大幅城楼静帧加下方三段人物弧线
- **Title**: 一截红布，改变陈峰理解历史的方式
- **Core message**: 现代研究者；战时陈小满；王根生红布；铭记普通人；12场104镜，完整设计10:36
- **Content**:
  - 现代研究者；战时陈小满；王根生红布；铭记普通人；12场104镜，完整设计10:36
- **Images**: image_014.png
- **Topology**: yes
- **Native-ready**: none

#### Slide 03 - 三人怎样交付同一个镜头

- **Audience move**: 从姓名到具体工作与交接文件
- **Relationships**: 武琮浩剧本→王珽沣分镜关键帧→杨义视频声音剪辑
- **Composition**: 三条贯穿页面的责任带，每带附1-11-07的交付例子
- **Title**: 三人怎样交付同一个镜头
- **Core message**: 武琮浩：台词与情绪；王珽沣：6秒执行卡、右腕红布；杨义：微动作、对白音轨与成片。ChatGPT/豆包、图像工具、Seedance 2.0/剪映；暂定分工
- **Content**:
  - 武琮浩：台词与情绪；王珽沣：6秒执行卡、右腕红布；杨义：微动作、对白音轨与成片。ChatGPT/豆包、图像工具、Seedance 2.0/剪映；暂定分工
- **Images**: none
- **Topology**: yes
- **Native-ready**: none

#### Slide 04 - 先把35秒，拆成五个能执行的镜头

- **Audience move**: 从剧本段落到逐镜约束
- **Relationships**: 1-1-01至05依次完成建立、疲惫、资料、白闪、空镜
- **Composition**: 左侧原始TXT截图，右侧镜号顺序与字段摘要
- **Title**: 先把35秒，拆成五个能执行的镜头
- **Core message**: 第一场35秒：6+7+5+10+7。提示词原文与关键帧相连；时代、空间、动作、声音分开约束
- **Content**:
  - 第一场35秒：6+7+5+10+7。提示词原文与关键帧相连；时代、空间、动作、声音分开约束
- **Images**: image_009.png
- **Topology**: yes
- **Native-ready**: none

#### Slide 05 - 1-1-01：用三处锚点锁住宿舍

- **Audience move**: 从画面好看到布局可核对
- **Relationships**: 窗、台灯、旧书地图共属固定宿舍场景
- **Composition**: 大幅完整关键帧，图内原生数字批注，底部精简提示词
- **Title**: 1-1-01：用三处锚点锁住宿舍
- **Core message**: 当代雨夜；门左后窗右后；冷蓝窗光与暖黄台灯；书名年份后期叠加。现图可见光线和桌面；精确文字不由模型承担
- **Content**:
  - 当代雨夜；门左后窗右后；冷蓝窗光与暖黄台灯；书名年份后期叠加。现图可见光线和桌面；精确文字不由模型承担
- **Images**: image_012.png
- **Topology**: no
- **Native-ready**: none

#### Slide 06 - 1-1-01：横移失稳时，先减少运动

- **Audience move**: 从首帧到可验证的视频方案
- **Relationships**: 基线横移→如结构漂移则减幅→仍失败用静帧轻推
- **Composition**: 上方宿舍画面延续，下面三阶段回退路径
- **Title**: 1-1-01：横移失稳时，先减少运动
- **Core message**: 0—2秒建立、2—4秒露出旧书地图、4—6秒停雨窗；检查台灯位移、书页扭曲、新增人物；这是报告复现方案，真实输出对照待补
- **Content**:
  - 0—2秒建立、2—4秒露出旧书地图、4—6秒停雨窗；检查台灯位移、书页扭曲、新增人物；这是报告复现方案，真实输出对照待补
- **Images**: image_012.png
- **Topology**: yes
- **Native-ready**: none

#### Slide 07 - 1-1-04：白光不能先把动作抹掉

- **Audience move**: 从效果优先到可读动作顺序
- **Relationships**: 雷光→惊起→过曝；画面与声音分轨
- **Composition**: 大幅原关键帧与右侧三项观察，底部白闪步骤
- **Title**: 1-1-04：白光不能先把动作抹掉
- **Core message**: 10秒有效段；当前图可辨陈峰起身、偏倒椅子、发白屏幕；白闪后期完成，书名与年份精确叠字
- **Content**:
  - 10秒有效段；当前图可辨陈峰起身、偏倒椅子、发白屏幕；白闪后期完成，书名与年份精确叠字
- **Images**: image_013.png
- **Topology**: no
- **Native-ready**: none

#### Slide 08 - 同一张脸，分清两套时代造型

- **Audience move**: 从参考图到身份和服装的分别校验
- **Relationships**: 现代与战时造型对照，身份保持、服装改变
- **Composition**: 两幅完整三视图对照，下方不变项和变化项
- **Title**: 同一张脸，分清两套时代造型
- **Core message**: 现代：黑框眼镜、灰卫衣；战时：灰布军装、绑腿与布鞋。现代与战时关键帧分开引用；名字不足以锁定身份；魏大勇=和尚
- **Content**:
  - 现代：黑框眼镜、灰卫衣；战时：灰布军装、绑腿与布鞋。现代与战时关键帧分开引用；名字不足以锁定身份；魏大勇=和尚
- **Images**: image_003.png,image_004.png
- **Topology**: no
- **Native-ready**: none

#### Slide 09 - 1-11-07：红布必须是叙事焦点

- **Audience move**: 从双人摆拍到人物、信物与代价的联系
- **Relationships**: 视线落红布，城下伤员触发沉默
- **Composition**: 全幅双人关键帧，腕带与背景伤员数字批注，底部观察和验收区别
- **Title**: 1-11-07：红布必须是叙事焦点
- **Core message**: 原图可见右腕红布、双人、城下担架；左侧人物手势朝城下，静帧不能证明先看红布的动作；视频需核对视线与腕带稳定
- **Content**:
  - 原图可见右腕红布、双人、城下担架；左侧人物手势朝城下，静帧不能证明先看红布的动作；视频需核对视线与腕带稳定
- **Images**: image_014.png
- **Topology**: no
- **Native-ready**: none

#### Slide 10 - 1-11-07：把一句台词拆成六秒表演

- **Audience move**: 从形容词到动作、固定项和替代拍法
- **Relationships**: TXT原文→0—2秒红布、2—4秒对白、4—6秒沉默→失败降复杂度
- **Composition**: 左侧TXT原文截图，右侧可复制提示词与三拍解释
- **Title**: 1-11-07：把一句台词拆成六秒表演
- **Core message**: 两人不换位，军装和右腕红布不变，固定或极小推镜、不生成口型；如漂移，先减手臂和抬头；仍失败用同轴反应镜与红布特写，后期独立配音
- **Content**:
  - 两人不换位，军装和右腕红布不变，固定或极小推镜、不生成口型；如漂移，先减手臂和抬头；仍失败用同轴反应镜与红布特写，后期独立配音
- **Images**: image_011.png
- **Topology**: yes
- **Native-ready**: none

#### Slide 11 - 1-11-10：先看清红布，再进入白光

- **Audience move**: 从一张过曝图到9秒转场设计
- **Relationships**: 0—3夕光、3—6抬右手红布、6—9渐白与抽声
- **Composition**: 左侧原关键帧与三项可读结构，右侧三个阶段文字
- **Title**: 1-11-10：先看清红布，再进入白光
- **Core message**: 现图保留脸、右手和腕带位置；不以整张白图作首帧；白闪和声音抽空由视频与后期分工；保持傍晚非黎明
- **Content**:
  - 现图保留脸、右手和腕带位置；不以整张白图作首帧；白闪和声音抽空由视频与后期分工；保持傍晚非黎明
- **Images**: image_015.png
- **Topology**: yes
- **Native-ready**: none

#### Slide 12 - E03：老兵动得越少，致敬越清楚

- **Audience move**: 从片尾图片到6秒可控动画
- **Relationships**: 保护人物接触、勋章和文案；微动→若不稳则只环境动
- **Composition**: 左侧完整片尾卡，右侧保护区及微动作清单，下方六镜顺序
- **Title**: E03：老兵动得越少，致敬越清楚
- **Core message**: 军装勋章退伍老兵非王根生生还；只呼吸、衣角树叶，不走位不转身；字形/勋章静态保护，失败后期轻推；E01—06共36秒
- **Content**:
  - 军装勋章退伍老兵非王根生生还；只呼吸、衣角树叶，不走位不转身；字形/勋章静态保护，失败后期轻推；E01—06共36秒
- **Images**: image_018.png
- **Topology**: no
- **Native-ready**: none

#### Slide 13 - 后期把两次白闪，做成一次情感回环

- **Audience move**: 从素材串联到声画具体处理
- **Relationships**: 第一场雨声抽走进入战时，第十一场人声抽空回现实
- **Composition**: 上下两条声画路径及底部明确时长公式
- **Title**: 后期把两次白闪，做成一次情感回环
- **Core message**: 剪映：画面按镜号、对白与环境音乐分轨、准确文字后叠；592+8+36=636秒；原说明09:52—10:00，延伸10:00—10:36
- **Content**:
  - 剪映：画面按镜号、对白与环境音乐分轨、准确文字后叠；592+8+36=636秒；原说明09:52—10:00，延伸10:00—10:36
- **Images**: none
- **Topology**: yes
- **Native-ready**: none

#### Slide 14 - 现有证据到哪里，答辩就讲到哪里

- **Audience move**: 从方法解释到成果、局限和下一步
- **Relationships**: 文件证据→现有静帧；视频参数截图仍待补
- **Composition**: 左侧三项证据结论，右侧旧书片尾与可点击成片入口
- **Title**: 现有证据到哪里，答辩就讲到哪里
- **Core message**: 已具剧本/TXT/关键帧/片尾；视频优化方案可复现，但不能凭静帧声称逐帧通过；下一步补真实前后帧、平台参数、导出信息。铭记普通人、珍惜和平
- **Content**:
  - 已具剧本/TXT/关键帧/片尾；视频优化方案可复现，但不能凭静帧声称逐帧通过；下一步补真实前后帧、平台参数、导出信息。铭记普通人、珍惜和平
- **Images**: image_021.png
- **Topology**: no
- **Native-ready**: none
- **Closing impact**: 用诚实的证据边界与旧书信物收束，不增加空泛口号。
- **Hyperlinks**: 完整成片 https://mega.nz/folder/0ygUwKqB#haymSgIw2WrSx8Ba8f3yeQ

## X. Speaker Notes Requirements

- **Generation**: enabled
- **Filename**: match SVG filename
- **Content**: 逐页解释报告中的实际输入、静帧可观察信息、修改理由、验收与局限；不编造历史生成结果。
- **Total duration**: 建议约6分钟，现场排练5—7分钟
